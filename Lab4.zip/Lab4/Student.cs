﻿using Lab4;
namespace Lab4
{
    public class Student: Person
    {
        public string Program { get; set; }
    }
}